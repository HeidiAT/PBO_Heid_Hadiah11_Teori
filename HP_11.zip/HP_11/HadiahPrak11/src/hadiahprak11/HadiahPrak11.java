package hadiahprak11;

/**
 *
 * @author RAMON
 */
import java.awt.*;
public class HadiahPrak11 extends Panel{

    /**
     * @param args the command line arguments
     */
    
    HadiahPrak11() {
        setBackground(Color.GRAY); //konstanta dalam color
    }
    
    public void paint(Graphics g) {
        Font f = new Font("Helvetica", Font.BOLD,20);
        FontMetrics fm = getFontMetrics(f);
        g.setFont(f);
        // kotak atas
        g.setColor(Color.blue);
        g.fillRect(50,8,380,80);
        g.drawRect(50,8,380,80);
        // kotak bawah
        g.setColor(Color.blue);
        g.fillRect(50,80,480,110);
        g.drawRect(50,80,480,110);
        //roda 1
        g.setColor(Color.red);
        g.drawOval(100, 150, 100, 100);
        g.fillOval(100,150,100,100);
        //roda 2
        g.setColor(Color.red);
        g.drawOval(330,150,100,100);
        g.fillOval(330,150,100,100);        
             
        
        String s = "Ini mobil dan nama saya Heidi";
        int xpos = (this.size().width - fm.stringWidth(s)) /2;
        int ypos = 300;
        g.setColor(Color.black);
        g.setFont(f);
        g.drawString(s, xpos, ypos);
    }
    public static void main(String[] args) {
        Frame f = new Frame("Testing Graphics Panel");
        HadiahPrak11 gp = new HadiahPrak11();
        f.add(gp);
        f.setSize(600,400);
        f.setVisible(true);
    }
    
}
